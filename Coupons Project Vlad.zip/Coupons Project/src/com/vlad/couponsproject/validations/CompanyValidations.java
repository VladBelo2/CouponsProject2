package com.vlad.couponsproject.validations;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.vlad.couponsproject.beans.Company;
import com.vlad.couponsproject.enums.errorType;
import com.vlad.couponsproject.exceptions.BusinessException;
import com.vlad.couponsproject.utils.FinalsClass;
import com.vlad.couponsproject.utils.GeneralHelpFunctions;

/**
 * validations class for company
 * 
 * @author Vlad Belo
 *
 */
public class CompanyValidations {

	//Validations for Companies

	/**
	 * This function validate email address 
	 * 
	 * @param email
	 * @throws BuisnesException
	 */
	public static void validateEmail(String email) throws BusinessException
	{
		if(!GeneralHelpFunctions.checkForInjection(email))
			throw new BusinessException(FinalsClass.ILIGAL_MAIL_ADRESS,errorType.INPUT_ERROR);

		//Email reg pattern
		final String EMAIL_PATTERN = "^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@"	+ "[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$";

		Pattern pattern = Pattern.compile(EMAIL_PATTERN);
		Matcher matcher = pattern.matcher(email);
		if(matcher.matches()==false)
			throw new BusinessException(FinalsClass.ILIGAL_MAIL_ADRESS,errorType.INPUT_ERROR);

	}

	/**
	 * Validate company name 
	 * 
	 * @param name
	 * @throws BuisnesException
	 */
	public static void validateCompanyName(String name) throws BusinessException
	{
		if(!GeneralHelpFunctions.checkForInjection(name))
			throw new BusinessException(FinalsClass.ILIGAL_COMPANY_NAME,errorType.INPUT_ERROR);
		if(name.length()<2)
			throw new BusinessException(FinalsClass.ILIGAL_COMPANY_NAME,errorType.INPUT_ERROR);	
	}

	/**
	 * Validate password field
	 * 
	 * @param password
	 * @throws BuisnesException
	 */
	public static void validatePassword(String password) throws BusinessException
	{
		if(!GeneralHelpFunctions.checkForInjection(password))
			throw new BusinessException(FinalsClass.ILIGAL_PASSWORD,errorType.INPUT_ERROR);
		if(password.length()<4)
			throw new BusinessException(FinalsClass.ILIGAL_PASSWORD,errorType.INPUT_ERROR);
	}

	/**
	 * check if the we didnt got one of the mandatory fields for create company
	 * 
	 * @param company
	 * @throws BuisnesException
	 */
	public static void ValidateForMandatoryFieldsCreateCompany(Company company) throws BusinessException
	{
		//check if company name is missing
		if(company.getCompName()==null)
			throw new BusinessException(FinalsClass.COMPANY_NAME_MISSING,errorType.INPUT_ERROR);

		//check if password is missing
		if(company.getPassword()==null)
			throw new BusinessException(FinalsClass.COMPANY_PASSWORD_MISSING,errorType.INPUT_ERROR);

		if(company.getEmail()==null)
			throw new BusinessException(FinalsClass.COMPANY_EMAIL_MISSING,errorType.INPUT_ERROR);
	}

	/**
	 * check if the we didn't got one of the mandatory fields for update company
	 * 
	 * @param company
	 * @throws BuisnesException
	 */
	public static void ValidateForMandatoryFieldsUpdateCompany(Company company) throws BusinessException
	{
		//check if company ID is missing
		if(Long.valueOf(company.getId())==null)
			throw new BusinessException(FinalsClass.COMPANY_ID_MISSING,errorType.INPUT_ERROR);

		//check if password is missing
		if(company.getPassword()==null)
			throw new BusinessException(FinalsClass.COMPANY_PASSWORD_MISSING,errorType.INPUT_ERROR);

		if(company.getEmail()==null)
			throw new BusinessException(FinalsClass.COMPANY_EMAIL_MISSING,errorType.INPUT_ERROR);

	}

	/**
	 * check if we didn't get mandatory fields for update company
	 * 
	 * @param companyName
	 * @throws BusinessException
	 */
	public static void ValidateForMandatoryFieldsCompanyName(String companyName) throws BusinessException
	{
		if(companyName==null)
			throw new BusinessException(FinalsClass.COMPANY_NAME_MISSING,errorType.INPUT_ERROR);

	}

	/**
	 * check if we didn't get mandatory fields for update company login
	 * 
	 * @param compName
	 * @param password
	 * @throws BusinessException
	 */
	public static void ValidateForMandatoryFieldsCompanyLogin(String compName, String password) throws BusinessException
	{
		if(compName==null )
			throw  new BusinessException(FinalsClass.COMPANY_NAME_MISSING,errorType.INPUT_ERROR);
		if(password==null)
			throw  new BusinessException(FinalsClass.COMPANY_PASSWORD_MISSING,errorType.INPUT_ERROR);
	}

}
