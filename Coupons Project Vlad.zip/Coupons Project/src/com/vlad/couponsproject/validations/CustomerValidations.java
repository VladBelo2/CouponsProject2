package com.vlad.couponsproject.validations;

import com.vlad.couponsproject.beans.Customer;
import com.vlad.couponsproject.enums.errorType;
import com.vlad.couponsproject.exceptions.BusinessException;
import com.vlad.couponsproject.utils.FinalsClass;
import com.vlad.couponsproject.utils.GeneralHelpFunctions;

/**
 * class of validations for customer controller
 * 
 * @author Vlad Belo
 *
 */
public class CustomerValidations {


	//customer validations

	/**
	 * Validate customer name field
	 * 
	 * @param name
	 * @throws BusinessException
	 */
	public static void validateCustomerName(String name) throws BusinessException
	{
		if(!GeneralHelpFunctions.checkForInjection(name))
			throw new BusinessException(FinalsClass.ILIGAL_CUSTOMER_NAME_FIELD,errorType.INPUT_ERROR);
		if(name.length()<2)
			throw new BusinessException(FinalsClass.ILIGAL_CUSTOMER_NAME_FIELD,errorType.INPUT_ERROR);
	}

	/**
	 * Validate customer user name
	 * 
	 * @param username
	 * @throws BusinessException
	 */
	public static void validateCustomerUsername(String username) throws BusinessException
	{
		if(!GeneralHelpFunctions.checkForInjection(username))
			throw new BusinessException(FinalsClass.ILIGAL_CUSTOMER_USERNAME_FIELD,errorType.INPUT_ERROR);
		if(username.length()<2)
			throw new BusinessException(FinalsClass.ILIGAL_CUSTOMER_USERNAME_FIELD,errorType.INPUT_ERROR);
	}

	/**
	 * Validate customer password
	 * 
	 * @param password
	 * @throws BusinessException
	 */
	public static void validateCustomerPassword(String password) throws BusinessException
	{
		if(!GeneralHelpFunctions.checkForInjection(password))
			throw new BusinessException(FinalsClass.ILIGAL_CUSTOMER_PASSWORD_FIELD,errorType.INPUT_ERROR);
		if(password.length()<2)
			throw new BusinessException(FinalsClass.ILIGAL_CUSTOMER_PASSWORD_FIELD,errorType.INPUT_ERROR);
	}

	/**
	 * check if the customer didn't enter mandatory fields for create customer
	 * 
	 * @param customer
	 * @throws BusinessException
	 */
	public static void ValidateMandatoryFieldsCreate(Customer customer) throws BusinessException
	{
		if(customer.getCustName()==null)
			throw new BusinessException(FinalsClass.CUSTOMER_MISSING_NAME_FIELD,errorType.INPUT_ERROR);
		if(customer.getUserName()==null)
			throw new BusinessException(FinalsClass.CUSTOMER_MISSING_USERNAME_FIELD,errorType.INPUT_ERROR);
		if(customer.getPassword()==null)
			throw new BusinessException(FinalsClass.CUSTOMER_MISSING_PASSWORD_FIELD,errorType.INPUT_ERROR);
	}

	/**
	 * Check if the customer didn't enter the mandatory fields for update company
	 * 
	 * @param customer
	 * @throws BusinessException
	 */
	public static void ValidateMandatoryFieldsUpdate(Customer customer) throws BusinessException
	{
		if(customer.getUserName()==null)
			throw new BusinessException(FinalsClass.CUSTOMER_MISSING_USERNAME_FIELD,errorType.INPUT_ERROR);
		if(customer.getPassword()==null)
			throw new BusinessException(FinalsClass.CUSTOMER_MISSING_PASSWORD_FIELD,errorType.INPUT_ERROR);

	}

	/**
	 * Check if the customer didn't enter the mandatory fields for login
	 * 
	 * @param username
	 * @param password
	 * @throws BusinessException
	 */
	public static void ValidateMandatoryFieldsLogin(String username, String password) throws BusinessException
	{
		if(username==null)
			throw new BusinessException(FinalsClass.CUSTOMER_MISSING_USERNAME_FIELD,errorType.INPUT_ERROR);
		if(password==null)
			throw new BusinessException(FinalsClass.CUSTOMER_MISSING_PASSWORD_FIELD,errorType.INPUT_ERROR);

	}

	/**
	 * Check if the customer didn't enter the mandatory fields customer name
	 * 
	 * @param customerName
	 * @throws BusinessException
	 */
	public static void ValidateMandatoryFieldsCustomerName(String customerName) throws BusinessException
	{
		if(customerName==null)
			throw new BusinessException(FinalsClass.CUSTOMER_MISSING_USERNAME_FIELD,errorType.INPUT_ERROR);
	}

	/**
	 * Check if the customer didn't enter the mandatory fields customer user name
	 * 
	 * @param userName
	 * @throws BusinessException
	 */
	public static void ValidateMandatoryFieldsCustomerUserName(String userName) throws BusinessException
	{
		if(userName==null)
			throw new BusinessException(FinalsClass.CUSTOMER_MISSING_USERNAME_FIELD,errorType.INPUT_ERROR);
	}
}
