package com.vlad.couponsproject.validations;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

import com.vlad.couponsproject.beans.Coupon;
import com.vlad.couponsproject.dao.CouponDao;
import com.vlad.couponsproject.enums.couponType;
import com.vlad.couponsproject.enums.errorType;
import com.vlad.couponsproject.exceptions.BusinessException;
import com.vlad.couponsproject.exceptions.CouponException;
import com.vlad.couponsproject.logger.CouponsLogger;
import com.vlad.couponsproject.utils.FinalsClass;
import com.vlad.couponsproject.utils.GeneralHelpFunctions;

/**
 * class of Validations checks for coupons 
 * 
 * @author Vlad Belo
 *
 */
public class CouponValidations {


	//Validations for Coupons

	//input validations 

	/**
	 * Validate coupon title field
	 * 
	 * @param title
	 * @throws BusinessException
	 */
	public static void validateCouponTitle(String title) throws BusinessException
	{
		if(!GeneralHelpFunctions.checkForInjection(title))
			throw new BusinessException(FinalsClass.ILIGAL_COUPON_TITLE_FIELD,errorType.INPUT_ERROR);
		if(title.length()<2)
			throw new BusinessException(FinalsClass.ILIGAL_COUPON_TITLE_FIELD,errorType.INPUT_ERROR);
	}

	/**
	 * Validate amount field
	 * 
	 * @param amount
	 * @throws BusinessException
	 */
	public static void validateAmount(int amount) throws BusinessException
	{
		if(amount < 1)
			throw new BusinessException(FinalsClass.ILIGAL_COUPON_AMOUNT_FIELD,errorType.INPUT_ERROR);
	}

	/**
	 * validate string that represent date 
	 * 
	 * @param stringDate
	 * @throws BusinessException
	 */
	public static void validateDate(String stringDate) throws BusinessException
	{
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-mm-dd");
		try {
			@SuppressWarnings("unused")
			Date date = formatter.parse(stringDate);
		}
		catch(ParseException e)
		{
			throw new BusinessException(FinalsClass.ILIGAL_COUPON_DATE_FIELD,errorType.INPUT_ERROR);
		}
	}

	/**
	 * validate coupon type 
	 *
	 * @param type
	 * @throws BusinessException
	 */
	public static void validateCouponType(couponType type) throws BusinessException
	{
		if(!couponType.isMember(type.toString()))
			throw new BusinessException(FinalsClass.ILIGAL_CCOUPON_TYPE_FIELD,errorType.INPUT_ERROR);
	}

	/**
	 * Validate coupon massage field 
	 * 
	 * @param massage
	 * @throws BusinessException
	 */
	public static void validateCouponMassage(String massage) throws BusinessException
	{
		if(!GeneralHelpFunctions.checkForInjection(massage))
			throw new BusinessException(FinalsClass.ILIGAL_COUPON_MASSAGE_FIELD,errorType.INPUT_ERROR);
		if(massage.length()<2)
			throw new BusinessException(FinalsClass.ILIGAL_COUPON_MASSAGE_FIELD,errorType.INPUT_ERROR);
	}

	/**
	 * Validate coupon price
	 * 
	 * @param price
	 * @throws BusinessException
	 */
	public static void validateCouponPrice(Double price) throws BusinessException
	{
		if(price < 1.0)
			throw new BusinessException(FinalsClass.ILIGAL_COUPON_PRICE_FIELD,errorType.INPUT_ERROR);
	}

	/**
	 * Validate coupon image field 
	 * 
	 * @param image
	 * @throws BusinessException
	 */
	public static void validateCouponImage(String image) throws BusinessException
	{
		if(!GeneralHelpFunctions.checkForInjection(image))
			throw new BusinessException(FinalsClass.ILIGAL_COUPON_IMAGE_FIELD,errorType.INPUT_ERROR);
		if(image.length()<2)
			throw new BusinessException(FinalsClass.ILIGAL_COUPON_IMAGE_FIELD,errorType.INPUT_ERROR);
	}

	/**
	 * Validate company ref field
	 * 
	 * @param companyRef
	 * @throws BusinessException
	 */
	public static void validateCouponCompanyRef(long companyRef) throws BusinessException
	{
		if(Long.valueOf(companyRef)==null)
			throw new BusinessException(FinalsClass.ILIGAL_COUPON_COMPANY_ID_FIELD,errorType.INPUT_ERROR);
	}

	/**
	 * Check if the customer didn't enter mandatory field coupon type
	 * 
	 * @param type
	 * @throws BusinessException
	 */
	public static void checkForMandatoryFieldType(couponType type) throws BusinessException
	{
		if(type== null)
			throw new BusinessException(FinalsClass.CCOUPON_MISING_TYPE_FIELD ,errorType.INPUT_ERROR);

	}

	/**
	 * Check if the customer didn't enter mandatory field end Date
	 * 
	 * @param endDate
	 * @throws BusinessException
	 */
	public static void checkForMandatoryFieldEndDate(String endDate) throws BusinessException
	{
		if(endDate== null)
			throw new BusinessException(FinalsClass.COUPON_MISING_END_DATE_FIELD ,errorType.INPUT_ERROR);

	}

	/**
	 * Check if the customer didn't enter mandatory field coupon name
	 * 
	 * @param couponName
	 * @throws BusinessException
	 */
	public static void checkForMandatoryFieldCouponName(String couponName) throws BusinessException
	{
		if(couponName==null)
			throw new BusinessException(FinalsClass.COUPON_MISSING_TITLE_FIELD,errorType.INPUT_ERROR);

	}

	/**
	 * Check if the customer didn't enter mandatory field for update coupon function
	 * 
	 * @param coupon
	 * @throws BusinessException
	 */
	public static void checkForMandatoryFieldUpdateCoupon(Coupon coupon) throws BusinessException
	{
		if(coupon.getStartDate()==null)
			throw new BusinessException(FinalsClass.COUPON_MISING_START_DATE_FIELD,errorType.INPUT_ERROR);

		if(coupon.getEndDate()==null)
			throw new BusinessException(FinalsClass.COUPON_MISING_END_DATE_FIELD ,errorType.INPUT_ERROR);

		if(Double.valueOf(coupon.getPrice())==null)
			throw new BusinessException(FinalsClass.COUPON_MISING_PRICE_FIELD,errorType.INPUT_ERROR);
	}


	//Business validations

	/**
	 * check if the start date is not after the end date
	 * 
	 * @param startDate
	 * @param endDate
	 * @throws BusinessException
	 */
	public static void checkDateOrders(String startDate,String endDate) throws BusinessException
	{
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-mm-dd");
		try {
			Date dateStart = formatter.parse(startDate);
			Date dateEnd = formatter.parse(endDate);

			if(dateStart.after(dateEnd))
				throw new BusinessException(FinalsClass.ILIGAL_COUPON_DATE_FIELD,errorType.INPUT_ERROR);
		}
		catch(ParseException e)
		{
			throw new BusinessException(FinalsClass.ILIGAL_COUPON_DATE_FIELD,errorType.INPUT_ERROR); 
		}
	}

	/**
	 * Check if the customer already bought the specific couponId 
	 * 
	 * @param customerId
	 * @param couponId
	 * @throws CouponException
	 */
	public static void checkIfAlreadyBoughtCoupon(long customerId,long couponId) throws CouponException
	{
		CouponDao couponDao = new CouponDao();

		ArrayList <Coupon> coupons = new  ArrayList<Coupon>();
		coupons = (ArrayList<Coupon>) couponDao.getCouponsByCustomer(customerId);

		if(coupons!= null)
		{
			for(Coupon coupon:coupons)
			{
				if(coupon.getId()==couponId)
					throw new BusinessException(FinalsClass.COUPON_ALREADY_BOUGHT,errorType.BUISNESS_ERROR);
			}
		}
	}

	/**
	 * check if a the amount is bigger then the quantity 
	 * 
	 * @param currAmount
	 * @param quntityBuy
	 * @throws BusinessException
	 */
	public static void checkCouponAmount(int currAmount,int quntityBuy) throws BusinessException
	{
		//calc the new amount
		int newAmount =  currAmount - quntityBuy;

		//if the amount of the coupon is 0 we throw exception
		if(newAmount<=0)
			throw new BusinessException(FinalsClass.NO_MORE_AMOUNT,errorType.BUISNESS_ERROR);

	}

	/**
	 * Check if the end date is not before the current date
	 * 
	 * @param endDate
	 * @throws CouponException
	 */
	public static void checkExpieryCoupon(String endDate) throws CouponException
	{
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-mm-dd");
		Calendar currentDate = Calendar.getInstance(); //Get the current date
		String date = formatter.format(currentDate.getTime());

		Date dateNow;
		Date dateEnd;

		//if we can't parse todays date its a internal problem 
		try {
			dateNow = formatter.parse(date);
		} catch (ParseException e1) {
			CouponsLogger logger = CouponsLogger.getInstance();
			logger.write(FinalsClass.DATE_GENERETE_FAIL);
			throw new BusinessException(FinalsClass.UNAVAILABLE_SERVICE,errorType.INTERNAL_ERROR);
		}

		//if we can't parse the input date its an input problem
		try {
			dateEnd = formatter.parse(endDate);
		} catch (ParseException e) {
			throw new BusinessException(FinalsClass.ILIGAL_COUPON_DATE_FIELD,errorType.INPUT_ERROR);
		}

		if(dateNow.after(dateEnd))
			throw new BusinessException(FinalsClass.EXPIERED_COUPON,errorType.BUISNESS_ERROR);

	}

	/**
	 * Check for mandatory fields for create coupon function
	 * 
	 * @param coupon
	 * @throws BusinessException
	 */
	public static void ValidateMandatoryFieldsCreate (Coupon coupon) throws BusinessException
	{
		//check for mandatory input
		if(coupon.getTitle()==null)
			throw new BusinessException(FinalsClass.COUPON_MISSING_TITLE_FIELD,errorType.INPUT_ERROR);

		if(coupon.getStartDate()==null)
			throw new BusinessException(FinalsClass.COUPON_MISING_START_DATE_FIELD,errorType.INPUT_ERROR);

		if(coupon.getEndDate()==null)
			throw new BusinessException(FinalsClass.COUPON_MISING_END_DATE_FIELD ,errorType.INPUT_ERROR);

		if(Double.valueOf(coupon.getAmount())==null)
			throw new BusinessException(FinalsClass.COUPON_MISING_AMOUNT_FIELD ,errorType.INPUT_ERROR);

		if(coupon.getType()==null)
			throw new BusinessException(FinalsClass.CCOUPON_MISING_TYPE_FIELD ,errorType.INPUT_ERROR);

		if(coupon.getMassage()==null)
			throw new BusinessException(FinalsClass.COUPON_MISING_MASSAGE_FIELD,errorType.INPUT_ERROR);

		if(Double.valueOf(coupon.getPrice())==null)
			throw new BusinessException(FinalsClass.COUPON_MISING_PRICE_FIELD,errorType.INPUT_ERROR);

		if(coupon.getImage()==null)
			throw new BusinessException(FinalsClass.COUPON_MISING_IMAGE_FIELD,errorType.INPUT_ERROR);

		if(Long.valueOf(coupon.getCompanyRef())==null)
			throw new BusinessException(FinalsClass.COUPON_MISING_COMPANY_ID_FIELD,errorType.INPUT_ERROR);
	}
}
