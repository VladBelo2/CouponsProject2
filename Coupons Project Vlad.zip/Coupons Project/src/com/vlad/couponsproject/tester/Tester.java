package com.vlad.couponsproject.tester;

import java.io.IOException;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

import com.vlad.couponsproject.beans.Company;
import com.vlad.couponsproject.beans.Coupon;
import com.vlad.couponsproject.beans.Customer;
import com.vlad.couponsproject.beans.LogCompany;
import com.vlad.couponsproject.beans.LogCoupon;
import com.vlad.couponsproject.beans.LogCustomer;
import com.vlad.couponsproject.dao.CompanyDao;
import com.vlad.couponsproject.dao.CouponDao;
import com.vlad.couponsproject.dao.CustomerDao;
import com.vlad.couponsproject.dao.LogCompanyDao;
import com.vlad.couponsproject.dao.LogCouponDao;
import com.vlad.couponsproject.dao.LogCustomerDao;
import com.vlad.couponsproject.enums.actionType;
import com.vlad.couponsproject.enums.couponType;
import com.vlad.couponsproject.enums.loginType;
import com.vlad.couponsproject.exceptions.CouponException;
import com.vlad.couponsproject.logic.CompanyController;
import com.vlad.couponsproject.logic.CouponController;
import com.vlad.couponsproject.utils.FinalsClass;
import com.vlad.couponsproject.utils.loginClass;
import com.vlad.couponsproject.validations.CouponValidations;

public class Tester {


	public static void main(String[] args) throws SQLException, CouponException, SecurityException, IOException
	{
		try
		{	
			String username = "vladbelo";
			String password = "vladbelo123";

			loginClass.login(username, password, loginType.CUSTOMER);
			System.out.println("Successs");
		}
		catch (Exception e)
		{
			System.out.println(e);
		}
	}

}
