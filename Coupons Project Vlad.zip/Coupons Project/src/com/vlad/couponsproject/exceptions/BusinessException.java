package com.vlad.couponsproject.exceptions;
import com.vlad.couponsproject.enums.errorType;

/**
 * Exception that we use when we want to notify the client of business error
 * @author Vlad Belo
 *
 */
@SuppressWarnings("serial")
public class BusinessException extends CouponException{
	private errorType error;


	public BusinessException ()
	{
		super();
	}

	public BusinessException(String message)
	{
		super(message);
	}

	//only if we initiate the exception throw
	public BusinessException(String message,errorType error)
	{
		super(message,error);
	}


	//only if we wrap up exception
	public BusinessException (Exception e,String message,errorType error)
	{
		super(e,message,error);
	}

	public errorType getErrorType()
	{
		return this.error;
	}

}




