package com.vlad.couponsproject.exceptions;

import java.util.HashMap;

import com.vlad.couponsproject.enums.errorType;

// Determine the exceptions using HashMap
public class ApplicationException extends Exception {

	protected Integer exceptionNumber;

	protected static HashMap<Integer, String> exceptionsMap;

	static {
		exceptionsMap = new HashMap<>();

		exceptionsMap.put(0, "**There was a problem creating this coupon**");
		exceptionsMap.put(1, "**There was a problem removing this coupon**");
		exceptionsMap.put(2, "**There was a problem updating this coupon**");
		exceptionsMap.put(3, "**This coupon doesn't exist**");
		exceptionsMap.put(4, "**There was a problem retrieving this coupon by it's name**");
		exceptionsMap.put(5, "**There was a problem retrieving all of the coupons from the DB**");
		exceptionsMap.put(6, "**There was a problem retrieving all of the coupons of this type from the DB**");
		exceptionsMap.put(7, "**There was a problem copying the data from the DB**");

		exceptionsMap.put(8, "**There was a problem creating this company**");
		exceptionsMap.put(9, "**There was a problem removing this company**");
		exceptionsMap.put(10, "**There was a problem updating this company**");
		exceptionsMap.put(11, "**This company doesn't exist**");
		exceptionsMap.put(12, "**There was a problem retrieving this company by it's name**");
		exceptionsMap.put(13, "**There was a problem retrieving all of the companies from the DB**");
		exceptionsMap.put(14, "**There was a problem with this company login**");
		exceptionsMap.put(15, "**There was a problem copying the data from the DB**");

		exceptionsMap.put(16, "**There was a problem creating this customer**");
		exceptionsMap.put(17, "**There was a problem removing this customer**");
		exceptionsMap.put(18, "**There was a problem updating this customer**");
		exceptionsMap.put(19, "**This customer doesn't exist**");
		exceptionsMap.put(20, "**There was a problem retrieving this customer by his name**");
		exceptionsMap.put(21, "**There was a problem retrieving all of the customers from the DB**");
		exceptionsMap.put(22, "**There was a problem with this customer login**");
		exceptionsMap.put(23, "**There was a problem copying the data from the DB**");

		exceptionsMap.put(24,"**there is already a company by this name**");
		exceptionsMap.put(25,"**there is already a customer by this name**");
		exceptionsMap.put(26,"**there is already a coupon by this name**");
		exceptionsMap.put(27,"**the details you entered were incorrect**");
		exceptionsMap.put(28,"**you already bougt this coupon. you can only buy it once**");
		exceptionsMap.put(29,"**coupon is out of stock**");
		exceptionsMap.put(30,"**there was a problem deleting the expired coupons **");

	}

	// constructors
	public ApplicationException(String string, errorType dataValidationError) {

	}

	public ApplicationException(int exceptionNumber) {
		this.exceptionNumber = exceptionNumber;
	}

	public ApplicationException(int exceptionNumber, Exception e) {
		super(e);
		this.exceptionNumber = exceptionNumber;
	}

	public ApplicationException(Exception e, errorType generalError, String string) {
	}

	public ApplicationException(errorType userError, String string) {
	}

	public ApplicationException(String string, errorType connectionError, Exception e) {
	}

	@Override
	public String toString() {
		return super.toString() + "\n\n" + exceptionsMap.get(this.exceptionNumber);
	}

}
