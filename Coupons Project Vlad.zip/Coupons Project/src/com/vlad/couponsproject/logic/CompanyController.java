package com.vlad.couponsproject.logic;

import java.util.ArrayList;
import java.util.Collection;

import com.vlad.couponsproject.beans.Company;
import com.vlad.couponsproject.beans.Coupon;
import com.vlad.couponsproject.dao.CompanyDao;
import com.vlad.couponsproject.dao.CouponDao;
import com.vlad.couponsproject.enums.errorType;
import com.vlad.couponsproject.exceptions.BusinessException;
import com.vlad.couponsproject.exceptions.CouponException;
import com.vlad.couponsproject.interfaces.ICompanyDao;
import com.vlad.couponsproject.utils.FinalsClass;
import com.vlad.couponsproject.validations.CompanyValidations;


/*
 * Class : Company Dao
 * Author : Vlad Belo
 * Version : 1.0
 * Date : 11.9.17
 */

public class CompanyController implements ICompanyDao{
	private CompanyDao companyDao = new CompanyDao();
	private CouponDao couponDao = new CouponDao();

	/*
	 * Public function: create company
	 * 
	 * Input: company
	 */
	@Override
	public void createCompany(Company company) throws CouponException {

		//check for mandatory input
		CompanyValidations.ValidateForMandatoryFieldsCreateCompany(company);

		//input Validations
		CompanyValidations.validateEmail(company.getEmail());
		CompanyValidations.validateCompanyName(company.getCompName());
		CompanyValidations.validatePassword(company.getPassword());

		//Check if the company name is already exist
		if(companyDao.getCompanyByName(company.getCompName())!=null)
			throw new BusinessException(FinalsClass.COMPANY_NAME_ALREADY_EXIST,errorType.BUISNESS_ERROR);

		//Create a new company after validation
		companyDao.createCompany(company);

	}

	/*
	 * Public function: remove company
	 * 
	 * Input: company id
	 */
	@Override
	public void removeCompany(long companyId) throws CouponException {

		//Check if the company ID is not exist
		if(companyDao.getCompanyByID(companyId) == null)
			throw new BusinessException(FinalsClass.NO_COMPANY_FOUND,errorType.BUISNESS_ERROR);

		removeCompanyAction(companyId);

	}

	/*
	 * private function: remove company
	 * 
	 * Input: company id
	 */
	private void removeCompanyAction(long companyId) throws CouponException
	{
		//Delete coupon of the same company 
		ArrayList <Coupon> coupons = new  ArrayList<Coupon>();
		coupons = (ArrayList<Coupon>) couponDao.getCouponsByCompany(companyId);

		if(coupons !=null) {
			for(Coupon coupon:coupons)
			{
				couponDao.removeCoupon(coupon.getId());
				couponDao.removeCustomerCouponByCoupn(coupon.getId());
			}
		}
		//Delete the company
		companyDao.removeCompany(companyId);	
	}

	/*
	 * Public function: update company
	 * 
	 * Input: company
	 */
	@Override
	public void updateCompany(Company company) throws CouponException {
		//Check for mandatory input 
		CompanyValidations.ValidateForMandatoryFieldsUpdateCompany(company);

		//Validate input values
		CompanyValidations.validatePassword(company.getPassword());
		CompanyValidations.validateEmail(company.getEmail());


		//Logic
		companyDao.updateCompany(company);
	}

	/*
	 * Public function: get all the companies
	 * 
	 * Input: no input
	 */
	@Override
	public Collection<Company> getAllCompanies() throws CouponException {
		return companyDao.getAllCompanies();
	}

	/*
	 * Public function: login
	 * return true if the login information is exist else return false
	 * 
	 * Input: company name , password
	 */
	@Override
	public boolean login(String compName, String password) throws CouponException {

		//check for mandatory fields
		CompanyValidations.ValidateForMandatoryFieldsCompanyLogin(compName, password);

		//Validate input fields
		CompanyValidations.validateCompanyName(compName);
		CompanyValidations.validatePassword(password);

		//Logic for login method
		return companyDao.login(compName, password);
	}

	/*
	 * Public function: get customer by id
	 * retrieve customer by id
	 * 
	 * Input: customer id
	 * 
	 */
	@Override
	public Company getCompanyByID(long companyId) throws CouponException {

		//Logic
		return companyDao.getCompanyByID(companyId);

	}

	/*
	 * Public function: get company by name
	 * 
	 * Input: company name
	 */
	@Override
	public Company getCompanyByName(String companyName) throws CouponException {

		//check for mandatory input
		CompanyValidations.ValidateForMandatoryFieldsCompanyName(companyName);

		//Validate input
		CompanyValidations.validateCompanyName(companyName);

		//Logic
		return companyDao.getCompanyByName(companyName);

	}
}
