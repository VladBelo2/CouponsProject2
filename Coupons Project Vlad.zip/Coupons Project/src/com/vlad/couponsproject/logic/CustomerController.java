package com.vlad.couponsproject.logic;

import java.util.Collection;

import com.vlad.couponsproject.beans.Customer;
import com.vlad.couponsproject.dao.CouponDao;
import com.vlad.couponsproject.dao.CustomerDao;
import com.vlad.couponsproject.enums.errorType;
import com.vlad.couponsproject.exceptions.BusinessException;
import com.vlad.couponsproject.exceptions.CouponException;
import com.vlad.couponsproject.interfaces.ICustomerDao;
import com.vlad.couponsproject.utils.FinalsClass;
import com.vlad.couponsproject.validations.CustomerValidations;

/*
 * Class : Customer Controller
 * Author : Vlad Belo
 * Version : 1.0
 * Date : 11.9.17
 */

public class CustomerController implements ICustomerDao{
	private CustomerDao customerDao = new CustomerDao();
	private CouponDao couponDao = new CouponDao();

	/*
	 * Public function: create customer
	 * create a new customer
	 * 
	 * Input: customer
	 */
	@Override
	public void createCustomer(Customer customer) throws CouponException {

		//check for mandatory input
		CustomerValidations.ValidateMandatoryFieldsCreate(customer);

		//input validations
		CustomerValidations.validateCustomerName(customer.getCustName());
		CustomerValidations.validateCustomerUsername(customer.getUserName());
		CustomerValidations.validateCustomerPassword(customer.getPassword());


		//check if the customer name already exists
		if(customerDao.getCustomerByName(customer.getCustName())!=null)
			throw new BusinessException(FinalsClass.CUSTOMER_ALREADY_EXCIST,errorType.BUISNESS_ERROR);

		//create new customer
		customerDao.createCustomer(customer);

	}

	/*
	 * Public function: remove customer
	 * remove a customer
	 * 
	 * Input: customer id
	 */
	@Override
	public void removeCustomer(long customerId) throws CouponException {

		//check if the customer does not exist
		if(customerDao.getCustomerByID(customerId)==null)
			throw new BusinessException(FinalsClass.NO_CUSTOMER_FOUND,errorType.BUISNESS_ERROR);

		//delete purchased coupon history by customer
		couponDao.removeCustomerCouponByCustomer(customerId);

		//delete customer
		customerDao.removeCustomer(customerId);
	}

	/*
	 * Public function: update customer
	 * update a customer
	 * 
	 * Input: customer
	 * 
	 */
	@Override
	public void updateCustomer(Customer customer) throws CouponException {

		//check for mandatory input
		CustomerValidations.ValidateMandatoryFieldsUpdate(customer);

		//check if the customer is not exist
		if(customerDao.getCustomerByID(customer.getId())==null)
			throw new BusinessException(FinalsClass.NO_CUSTOMER_FOUND,errorType.BUISNESS_ERROR);

		//validate input fields
		CustomerValidations.validateCustomerUsername(customer.getUserName());
		CustomerValidations.validateCustomerPassword(customer.getPassword());

		//logic
		customerDao.updateCustomer(customer);
	}

	/*
	 * Public function: get all the customers
	 * retrieve all the customers 
	 * 
	 * Input: no input
	 */
	@Override
	public Collection<Customer> getAllCustomers() throws CouponException {
		return customerDao.getAllCustomers();
	}

	/*
	 * Public function: login
	 * return true if the login information is exist else return false
	 * 
	 * Input: customer name , password
	 */
	@Override
	public boolean login(String username, String password) throws CouponException {

		//check for mandatory input
		CustomerValidations.ValidateMandatoryFieldsLogin(username, password);

		//validate input fields
		CustomerValidations.validateCustomerUsername(username);
		CustomerValidations.validateCustomerPassword(password);

		//logic
		return customerDao.login(username,password);
	}

	/*
	 * Public function: get customer by id
	 * retrieve customer by id
	 * 
	 * Input: customer id
	 */
	@Override
	public Customer getCustomerByID(long customerId) throws CouponException {

		//logic
		return customerDao.getCustomerByID(customerId);
	}

	/*
	 * Public function: get customer by name
	 * retrieve customer by name
	 * 
	 * Input: customer name
	 */
	@Override
	public Customer getCustomerByName(String customerName) throws CouponException {

		//check for mandatory input
		CustomerValidations.ValidateMandatoryFieldsCustomerName(customerName);

		//Validate input fields
		CustomerValidations.validateCustomerName(customerName);

		//logic
		return customerDao.getCustomerByName(customerName);
	}

	/*
	 * Public function: get customer by username
	 * retrieve customer by username
	 * 
	 * Input: customer username
	 */
	@Override
	public Customer getCustomerByUsername(String username) throws CouponException {

		//check for mandatory input
		CustomerValidations.ValidateMandatoryFieldsCustomerUserName(username);

		//Validate input fields
		CustomerValidations.validateCustomerUsername(username);

		//logic
		return customerDao.getCustomerByUsername(username);
	}

}
