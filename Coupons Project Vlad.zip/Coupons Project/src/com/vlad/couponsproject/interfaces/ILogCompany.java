package com.vlad.couponsproject.interfaces;

import com.vlad.couponsproject.beans.LogCompany;
import com.vlad.couponsproject.exceptions.CouponException;

public interface ILogCompany {

	public void insertToCompenyLog (LogCompany logcompany) throws CouponException;
}
