package com.vlad.couponsproject.interfaces;

import com.vlad.couponsproject.beans.LogCoupon;
import com.vlad.couponsproject.exceptions.CouponException;

public interface ILogCoupon {
	public void insertToCouponLog (LogCoupon logcoupon) throws CouponException;

	public void insertToLogCustomerCoupons(long customerID,long CoupomID) throws CouponException;
}
