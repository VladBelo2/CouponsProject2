package com.vlad.couponsproject.interfaces;

import com.vlad.couponsproject.beans.LogCustomer;
import com.vlad.couponsproject.exceptions.CouponException;

public interface ILogCustomer {

	public void insertToCustomerLog (LogCustomer logcustomer) throws CouponException;
}
