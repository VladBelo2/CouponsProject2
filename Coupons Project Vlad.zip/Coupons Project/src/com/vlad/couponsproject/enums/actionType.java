package com.vlad.couponsproject.enums;

public enum actionType {
	CREATE,
	REMOVE,
	UPDATE,
	RETRIEVE_BY_ID,
	RETRIEVE_BY_COMPANY,
	RETRIEVE_BY_TYPE,
	RETRIEVE_ALL,
	LOGIN,
	PURSHED;
}
