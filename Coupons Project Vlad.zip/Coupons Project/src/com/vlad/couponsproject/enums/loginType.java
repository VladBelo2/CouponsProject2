package com.vlad.couponsproject.enums;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public enum loginType {
	ADMIN,CUSTOMER,COMPANY;
}
