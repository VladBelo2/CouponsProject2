package com.vlad.couponsproject.enums;

public enum Type {
	Restuartnts,
	Food,
	Electricity,
	Health,
	Sports,
	Camping,
	Traveling;

}
