package com.vlad.couponsproject.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import com.vlad.couponsproject.beans.LogCustomer;
import com.vlad.couponsproject.enums.errorType;
import com.vlad.couponsproject.exceptions.WriteToLogException;
import com.vlad.couponsproject.interfaces.ILogCustomer;
import com.vlad.couponsproject.logger.CouponsLogger;
import com.vlad.couponsproject.utils.FinalsClass;
import com.vlad.couponsproject.utils.JdbcUtils;

public class LogCustomerDao implements ILogCustomer{

	private void writeToLog(Exception e) throws WriteToLogException
	{
		CouponsLogger daoLogger = CouponsLogger.getInstance();
		daoLogger.write(e.toString());
	}

	@Override
	public void insertToCustomerLog(LogCustomer logcustomer) throws WriteToLogException {
		//creating the resources
		PreparedStatement preparedStatement = null;
		Connection connection = null;
		ResultSet resultSet = null;

		try
		{
			//getting a connection from the connection manager
			connection = JdbcUtils.getConnection();
			//creating the SQL query
			String sql = "insert into logCustomers (actionType,customerID,customerName, userName,password,executionTimeStamp ) "
					+ "values (?,?,?,?,?,?)";

			// Creating a statement object which holds the SQL we're about to execute and asking for the generated keys back
			preparedStatement = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);

			//asking to Replace the question marks in the statement above with the following data
			preparedStatement.setString(1, logcustomer.getAction().toString());
			preparedStatement.setLong(2, logcustomer.getCustomerId());
			preparedStatement.setString(3, logcustomer.getCustName());
			preparedStatement.setString(4, logcustomer.getUserName());
			preparedStatement.setString(5, logcustomer.getPassword());
			preparedStatement.setString(6, logcustomer.getExecutionTimeStamp());




			//executing the update
			preparedStatement.executeUpdate();

		}
		catch(Exception e)
		{
			writeToLog(e);
			throw new WriteToLogException(FinalsClass.UNAVAILABLE_SERVICE,errorType.INTERNAL_ERROR);
		}

		finally
		{
			JdbcUtils.closeResources(connection, preparedStatement, resultSet);
		}
	}
}
