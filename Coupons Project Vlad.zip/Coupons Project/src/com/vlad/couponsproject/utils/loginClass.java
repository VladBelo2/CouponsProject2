package com.vlad.couponsproject.utils;

import com.vlad.couponsproject.enums.errorType;
import com.vlad.couponsproject.enums.loginType;
import com.vlad.couponsproject.exceptions.BusinessException;
import com.vlad.couponsproject.exceptions.CouponException;
import com.vlad.couponsproject.logic.CompanyController;
import com.vlad.couponsproject.logic.CustomerController;

/**
 * Class of login to the coupon system
 * 
 * @author Vlad Belo
 *
 */
public final class loginClass {
	//The class and login functions is final so no one can override the login and login

	/**
	 * login function for the coupon site , the function is final so it can't be overwrite
	 * 
	 * @param username
	 * @param password
	 * @param type
	 * @throws CouponException
	 */
	public static final void login(String username,String password,loginType type) throws CouponException
	{
		if(type == loginType.ADMIN)
		{
			if(username != "admin" || password != "1234")
				throw new BusinessException(FinalsClass.WRONG_LOGIN_INFO ,errorType.BUISNESS_ERROR);

		}
		else if(type == loginType.COMPANY)
		{
			CompanyController companyController = new CompanyController();
			if(!companyController.login(username, password))
				throw new BusinessException(FinalsClass.WRONG_LOGIN_INFO ,errorType.BUISNESS_ERROR);
		}
		else if(type == loginType.CUSTOMER)
		{
			CustomerController customerController = new CustomerController();
			if(!customerController.login(username, password))
				throw new BusinessException(FinalsClass.WRONG_LOGIN_INFO ,errorType.BUISNESS_ERROR);	
		}

		else
		{
			throw new BusinessException(FinalsClass.UNAVAILABLE_SERVICE,errorType.INPUT_ERROR);
		}
	}
}
