package com.vlad.couponsproject.utils;

import java.util.regex.Matcher;
import java.util.regex.Pattern;
import com.vlad.couponsproject.exceptions.ApplicationException;

public class DataValidationUtils {

	// Validates password under several criteria
	public static boolean validatePassword(String password, String name) throws ApplicationException{

		if (!checkLowerAndUpperCasePassword(password)){
			return false;
		}

		if (compareNameAndPassword(name, password)){
			return false;
		}

		if (passwordLowerThan8Tabs(password)){
			return false;
		}

		return true;
	}

	//Checking that the password is 8 characters or more
	private static boolean passwordLowerThan8Tabs(String password){

		if (password.length()<8){
			return true;
		}
		return false;
	}

	//Checking if the password contains both upper-case and lower case characters
	private static boolean checkLowerAndUpperCasePassword(String password) {
		if (password.toUpperCase()==password || password.toLowerCase()==password){
			return false;
		}
		return true;
	}

	//Validating that company name and password can't match.
	private static boolean compareNameAndPassword(String companyName, String password) {
		if (companyName.toLowerCase().equals(password.toLowerCase())){
			return true;
		}
		return false;
	}

	//Email validation -according to specific format
	public static boolean validateEmail(String email) throws ApplicationException{
		final Pattern VALID_EMAIL_ADDRESS_REGEX = 
				Pattern.compile("^[A-Z0-9._%+-]+@[A-Z0-9.-]+\\.[A-Z]{2,6}$", Pattern.CASE_INSENSITIVE);

		Matcher matcher = VALID_EMAIL_ADDRESS_REGEX .matcher(email);

		return matcher.find();
	}
}
