package com.vlad.couponsproject.api;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;

import com.vlad.couponsproject.beans.LoginInput;
import com.vlad.couponsproject.exceptions.CouponException;
import com.vlad.couponsproject.utils.loginClass;

@Path("/login")
public class LoginAPI {
	@Context private HttpServletRequest request;

	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	public void login(LoginInput loginInput) throws CouponException{
		//call to login util
		loginClass.login(loginInput.getUsername(), loginInput.getPassword(), loginInput.getType());
		//if the login fail it will throw exception and wont get to the session

		request.getSession(true);
	}
}
