package com.vlad.couponsproject.api;

import javax.ws.rs.core.Response;
import javax.ws.rs.ext.ExceptionMapper;
import javax.ws.rs.ext.Provider;

import com.vlad.couponsproject.exceptions.BusinessException;
import com.vlad.couponsproject.exceptions.GeneralException;

@Provider
public class ExceptionsHandler extends Exception implements ExceptionMapper<Throwable> 
{
	@Override
	public Response toResponse(Throwable exception) 
	{

		//GeneralException
		if (exception instanceof GeneralException){
			GeneralException e = (GeneralException) exception;

			String message = e.getErrorType().toString();
			return Response.status(600).entity(message).build();
		}

		//BusinessException
		if (exception instanceof BusinessException){
			BusinessException e = (BusinessException) exception;

			String message = e.getErrorType().toString();
			return Response.status(605).entity(message).build();
		}    	
		//if its not both send general fail
		return Response.status(500).entity("General failure").build();
	}
}